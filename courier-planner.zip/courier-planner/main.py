"""Intelligent courier planner: ordered delivery route + packing plan."""
import argparse
import os
from courier.instance import generate_instance, load, save
from courier.planner import CourierPlanner, STRATEGIES
from courier.report import print_comparison, print_plan
from courier.visualize import write_svg


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--input", help="instance JSON (see data/sample_instance.json)")
    ap.add_argument("--points", type=int, default=12, help="demo: number of delivery points")
    ap.add_argument("--parcels", type=int, default=30, help="demo: number of parcels")
    ap.add_argument("--max-weight", type=int, default=40)
    ap.add_argument("--max-volume", type=int, default=30)
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--strategy", choices=("auto",) + STRATEGIES, default="auto")
    ap.add_argument("--express-weight", type=float, default=1.0,
                    help="auto mode: how much to penalise slow express delivery")
    ap.add_argument("--exact-limit", type=int, default=12,
                    help="max stops per trip for the exact Held-Karp DP")
    ap.add_argument("--out", default="output")
    a = ap.parse_args()

    inst = load(a.input) if a.input else generate_instance(
        a.points, a.parcels, a.max_weight, a.max_volume, a.seed)
    os.makedirs(a.out, exist_ok=True)

    planner = CourierPlanner(inst, exact_limit=a.exact_limit, seed=a.seed)
    best, plans = planner.best_plan(a.express_weight)
    chosen = best if a.strategy == "auto" else next(p for p in plans if p["strategy"] == a.strategy)

    print_comparison(plans, chosen)
    print_plan(chosen, planner.cap_w, planner.cap_v, planner.depot)

    save(chosen, os.path.join(a.out, "plan.json"))
    write_svg(planner, chosen, os.path.join(a.out, "route_map.svg"))
    print(f"Saved {a.out}/plan.json and {a.out}/route_map.svg")


if __name__ == "__main__":
    main()
