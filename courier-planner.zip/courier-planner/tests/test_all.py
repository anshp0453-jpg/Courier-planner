import itertools, os, random, sys, unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from courier.sorting import merge_sort
from courier.graph import Graph
from courier.models import Parcel
from courier.knapsack import knapsack_2d, knapsack_greedy
from courier.tsp import held_karp, mst_two_approx, two_opt, tour_cost
from courier.instance import generate_instance
from courier.planner import CourierPlanner, STRATEGIES


def random_metric(n, seed):
    rng = random.Random(seed)
    pts = {f"n{i}": (rng.random() * 50, rng.random() * 50) for i in range(n)}
    g = Graph()
    for k, (x, y) in pts.items():
        g.add_node(k, x, y)
    for u, v in itertools.combinations(pts, 2):
        g.add_edge(u, v, ((pts[u][0]-pts[v][0])**2 + (pts[u][1]-pts[v][1])**2) ** .5)
    ids = list(pts)
    d, _ = g.distance_matrix(ids)
    return ids[0], ids[1:], d


class Tests(unittest.TestCase):
    def test_merge_sort_matches_builtin_and_is_stable(self):
        rng = random.Random(1)
        xs = [(rng.randint(0, 9), i) for i in range(200)]
        self.assertEqual(merge_sort(xs, key=lambda t: t[0]), sorted(xs, key=lambda t: t[0]))
        self.assertEqual(merge_sort(xs, key=lambda t: t[0], reverse=True),
                         sorted(xs, key=lambda t: -t[0]))

    def test_dijkstra(self):
        g = Graph()
        for n in "ABCD":
            g.add_node(n, 0, 0)
        g.add_edge("A", "B", 1); g.add_edge("B", "C", 2); g.add_edge("A", "C", 10); g.add_edge("C", "D", 1)
        dist, prev = g.dijkstra("A")
        self.assertEqual(dist["D"], 4)
        self.assertEqual(g.reconstruct(prev, "A", "D"), ["A", "B", "C", "D"])

    def test_knapsack_optimal_vs_bruteforce(self):
        rng = random.Random(3)
        for _ in range(20):
            items = [Parcel(f"p{i}", "x", rng.randint(1, 6), rng.randint(1, 6),
                            rng.choice(["express", "standard", "economy"])) for i in range(8)]
            best = max(sum(p.value for p in c)
                       for r in range(9) for c in itertools.combinations(items, r)
                       if sum(p.weight for p in c) <= 12 and sum(p.volume for p in c) <= 10)
            val, chosen = knapsack_2d(items, 12, 10)
            self.assertEqual(val, best)
            self.assertLessEqual(sum(p.weight for p in chosen), 12)
            self.assertLessEqual(sum(p.volume for p in chosen), 10)
            self.assertLessEqual(knapsack_greedy(items, 12, 10)[0], val)

    def test_tsp_exact_and_approximation_bound(self):
        for seed in range(15):
            depot, stops, d = random_metric(8, seed)
            brute = min(tour_cost([depot, *perm, depot], d) for perm in itertools.permutations(stops))
            hk, _ = held_karp(depot, stops, d)
            self.assertAlmostEqual(hk, brute)
            mst, tour = mst_two_approx(depot, stops, d)
            self.assertLessEqual(mst, 2 * hk + 1e-9)             # 2-approximation guarantee
            self.assertEqual(sorted(tour[1:-1]), sorted(stops))  # visits every stop once
            self.assertLessEqual(two_opt(tour, d)[0], mst + 1e-9)

    def test_end_to_end_plan_is_valid(self):
        inst = generate_instance(12, 40, 40, 30, seed=5)
        pl = CourierPlanner(inst)
        for s in STRATEGIES:
            plan = pl.plan(s)
            ids = [p["id"] for t in plan["trips"] for p in t["parcels"]]
            self.assertEqual(sorted(ids), sorted(p["id"] for p in inst["parcels"]))  # each once
            for t in plan["trips"]:
                self.assertLessEqual(t["load_weight"], 40)
                self.assertLessEqual(t["load_volume"], 30)
                self.assertEqual(sorted(t["loading_order"]), sorted(p["id"] for p in t["parcels"]))
            self.assertGreaterEqual(plan["metrics"]["trips"], plan["metrics"]["trip_lower_bound"])

    def test_oversize_parcel_rejected(self):
        inst = generate_instance(5, 5, 40, 30, seed=1)
        inst["parcels"].append({"id": "BIG", "dest": "P1", "weight": 999, "volume": 1})
        pl = CourierPlanner(inst)
        self.assertEqual(pl.rejected[0][0], "BIG")


if __name__ == "__main__":
    unittest.main()
