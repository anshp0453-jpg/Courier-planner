"""Dependency-free SVG route map."""
COLORS = ["#e6194b", "#3cb44b", "#4363d8", "#f58231", "#911eb4", "#008080",
          "#9a6324", "#800000", "#808000", "#000075"]


def write_svg(planner, plan, path, size=800, pad=40):
    pos = planner.pos
    xs, ys = [p[0] for p in pos.values()], [p[1] for p in pos.values()]
    x0, y0, x1, y1 = min(xs), min(ys), max(xs), max(ys)
    sc = (size - 2 * pad) / max(x1 - x0, y1 - y0, 1)
    P = lambda n: (pad + (pos[n][0] - x0) * sc, size - pad - (pos[n][1] - y0) * sc)

    out = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {size} {size+30}" '
           f'font-family="sans-serif" font-size="11"><rect width="100%" height="100%" fill="white"/>']
    seen = set()
    for u, nb in planner.graph.adj.items():
        for v in nb:
            if (v, u) not in seen:
                seen.add((u, v))
                (a, b), (c, d) = P(u), P(v)
                out.append(f'<line x1="{a:.1f}" y1="{b:.1f}" x2="{c:.1f}" y2="{d:.1f}" stroke="#ddd"/>')
    for t in plan["trips"]:
        col = COLORS[(t["trip"] - 1) % len(COLORS)]
        pts = " ".join(f"{P(n)[0]:.1f},{P(n)[1]:.1f}" for n in t["road_path"])
        out.append(f'<polyline points="{pts}" fill="none" stroke="{col}" stroke-width="2.5" opacity="0.8"/>')
    used = {s for t in plan["trips"] for s in t["stops"]}
    for n in pos:
        x, y = P(n)
        if n == planner.depot:
            out.append(f'<rect x="{x-7:.1f}" y="{y-7:.1f}" width="14" height="14" fill="black"/>'
                       f'<text x="{x+10:.1f}" y="{y+4:.1f}" font-weight="bold">DEPOT</text>')
        else:
            fill = "#333" if n in used else "#bbb"
            out.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="5" fill="{fill}"/>'
                       f'<text x="{x+8:.1f}" y="{y+4:.1f}">{n}</text>')
    for t in plan["trips"]:
        col = COLORS[(t["trip"] - 1) % len(COLORS)]
        lx = pad + ((t["trip"] - 1) % 5) * 150
        ly = size + 10 + ((t["trip"] - 1) // 5) * 14
        out.append(f'<rect x="{lx}" y="{ly-8}" width="12" height="4" fill="{col}"/>'
                   f'<text x="{lx+16}" y="{ly-3}">Trip {t["trip"]} ({t["distance"]:.0f})</text>')
    out.append("</svg>")
    with open(path, "w") as f:
        f.write("\n".join(out))
