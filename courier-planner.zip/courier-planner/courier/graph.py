"""GRAPH ALGORITHMS: weighted road network, Dijkstra, connectivity."""
import heapq
import math
import random

INF = float("inf")


class Graph:
    def __init__(self):
        self.adj = {}   # node -> {neighbour: weight}
        self.pos = {}   # node -> (x, y)

    def add_node(self, nid, x, y):
        self.pos[nid] = (x, y)
        self.adj.setdefault(nid, {})

    def add_edge(self, u, v, w):
        if u == v:
            return
        if v in self.adj[u] and self.adj[u][v] <= w:
            return
        self.adj[u][v] = w
        self.adj[v][u] = w

    def dijkstra(self, src):
        """Single-source shortest paths with a binary heap: O((V+E) log V)."""
        dist = {n: INF for n in self.adj}
        prev = {}
        dist[src] = 0.0
        pq = [(0.0, src)]
        while pq:
            d, u = heapq.heappop(pq)
            if d > dist[u]:
                continue
            for v, w in self.adj[u].items():
                nd = d + w
                if nd < dist[v]:
                    dist[v] = nd
                    prev[v] = u
                    heapq.heappush(pq, (nd, v))
        return dist, prev

    @staticmethod
    def reconstruct(prev, src, dst):
        path = [dst]
        while path[-1] != src:
            path.append(prev[path[-1]])
        return path[::-1]

    def distance_matrix(self, nodes):
        """Metric closure over `nodes`: shortest road distance for every pair.
        Because these are shortest-path distances the triangle inequality
        holds, which is what the MST 2-approximation needs."""
        dist, prevs = {}, {}
        for s in nodes:
            d, p = self.dijkstra(s)
            dist[s] = {t: d[t] for t in nodes}
            prevs[s] = p
        return dist, prevs


def _euclid(a, b):
    return math.hypot(a[0] - b[0], a[1] - b[1])


def build_road_network(pos, k=3, seed=0):
    """Connect each node to its k nearest neighbours, then stitch any
    disconnected components together (union-find) so every stop is reachable.
    Road length = straight-line distance * a detour factor in [1, 1.25]."""
    rng = random.Random(seed)
    g = Graph()
    for n, (x, y) in pos.items():
        g.add_node(n, x, y)
    ids = list(pos)
    for u in ids:
        near = sorted((v for v in ids if v != u), key=lambda v: _euclid(pos[u], pos[v]))[:k]
        for v in near:
            g.add_edge(u, v, _euclid(pos[u], pos[v]) * (1 + 0.25 * rng.random()))

    parent = {n: n for n in ids}

    def find(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]
            a = parent[a]
        return a

    for u in ids:
        for v in g.adj[u]:
            parent[find(u)] = find(v)
    while len({find(n) for n in ids}) > 1:
        best = None
        for u in ids:
            for v in ids:
                if find(u) != find(v):
                    d = _euclid(pos[u], pos[v])
                    if best is None or d < best[0]:
                        best = (d, u, v)
        _, u, v = best
        g.add_edge(u, v, best[0] * 1.1)
        parent[find(u)] = find(v)
    return g
