"""Orchestrates: graph -> packing -> routing -> loading order -> metrics."""
import math
from .models import Parcel, PRIORITY_VALUE
from .graph import Graph, build_road_network, INF
from .sorting import merge_sort
from .packing import (first_fit_decreasing, plan_trips_priority, plan_trips_sweep,
                      lower_bound_trips)
from .tsp import solve_route

STRATEGIES = ("priority", "sweep", "ffd")


class CourierPlanner:
    def __init__(self, inst, exact_limit=12, seed=0):
        self.exact_limit = exact_limit
        self.depot = inst["depot"]["id"]
        pos = {self.depot: (inst["depot"]["x"], inst["depot"]["y"])}
        for p in inst["points"]:
            pos[p["id"]] = (p["x"], p["y"])
        self.pos = pos

        if inst.get("roads"):
            g = Graph()
            for n, (x, y) in pos.items():
                g.add_node(n, x, y)
            for u, v, w in inst["roads"]:
                g.add_edge(u, v, w)
        else:
            g = build_road_network(pos, k=3, seed=seed)
        self.graph = g

        self.cap_w = int(inst["vehicle"]["max_weight"])
        self.cap_v = int(inst["vehicle"]["max_volume"])

        self.parcels, self.rejected = [], []
        for r in inst["parcels"]:
            pr = r.get("priority", "standard")
            pr = pr if pr in PRIORITY_VALUE else "standard"
            p = Parcel(r["id"], r["dest"], math.ceil(r["weight"]), math.ceil(r["volume"]), pr)
            if p.dest not in pos:
                self.rejected.append((p.id, "unknown delivery point"))
            elif p.weight > self.cap_w or p.volume > self.cap_v:
                self.rejected.append((p.id, "exceeds vehicle capacity"))
            else:
                self.parcels.append(p)

        nodes = [self.depot] + sorted({p.dest for p in self.parcels})
        self.dist, self.prevs = g.distance_matrix(nodes)
        if any(self.dist[self.depot][n] == INF for n in nodes):
            raise ValueError("some delivery points are unreachable from the depot")

    # ---- trip construction -------------------------------------------------
    def _group(self, strategy):
        if strategy == "priority":
            return plan_trips_priority(self.parcels, self.cap_w, self.cap_v)
        if strategy == "sweep":
            return plan_trips_sweep(self.parcels, self.pos, self.depot, self.cap_w, self.cap_v)
        if strategy == "ffd":
            return first_fit_decreasing(self.parcels, self.cap_w, self.cap_v)
        raise ValueError(f"unknown strategy {strategy}")

    def _arrivals(self, order, start=0.0):
        t, prev, out = start, self.depot, {}
        for s in order:
            t += self.dist[prev][s]
            out[s] = t
            prev = s
        return out, t + self.dist[prev][self.depot]

    def _build_trip(self, no, group, offset):
        stops = sorted({p.dest for p in group})
        route = solve_route(self.depot, stops, self.dist, self.exact_limit)

        # Tour is symmetric: deliver in whichever direction serves high-priority
        # stops sooner.
        def urgency(order):
            arr, _ = self._arrivals(order)
            return sum(PRIORITY_VALUE[p.priority] * arr[p.dest] for p in group)
        order = route["order"]
        if urgency(order[::-1]) < urgency(order):
            order = order[::-1]

        arrivals, end = self._arrivals(order, offset)
        full_path, prev = [self.depot], self.depot
        for s in order + [self.depot]:
            full_path += self.graph.reconstruct(self.prevs[prev], prev, s)[1:]
            prev = s

        idx = {s: i for i, s in enumerate(order)}
        loading = merge_sort(group, key=lambda p: (-idx[p.dest], p.id))  # LIFO
        return {
            "trip": no,
            "stops": order,
            "road_path": full_path,
            "distance": end - offset,
            "route_method": route["method"],
            "route_info": {k: route[k] for k in
                           ("mst_cost", "mst_2opt_cost", "exact_cost", "ratio_mst", "ratio_2opt")},
            "load_weight": sum(p.weight for p in group),
            "load_volume": sum(p.volume for p in group),
            "loading_order": [p.id for p in loading],
            "parcels": [{"id": p.id, "dest": p.dest, "priority": p.priority,
                         "weight": p.weight, "volume": p.volume,
                         "delivered_at": arrivals[p.dest]} for p in group],
        }, end

    # ---- public API --------------------------------------------------------
    def plan(self, strategy="priority"):
        groups = self._group(strategy) if self.parcels else []
        # Run trips with the most urgent cargo first
        groups = merge_sort(groups, key=lambda g: -sum(PRIORITY_VALUE[p.priority] for p in g))
        trips, offset = [], 0.0
        for i, g in enumerate(groups, 1):
            t, offset = self._build_trip(i, g, offset)
            trips.append(t)
        times = [(p["priority"], p["delivered_at"]) for t in trips for p in t["parcels"]]
        exp = [d for pr, d in times if pr == "express"]
        n = len(trips)
        return {
            "strategy": strategy,
            "trips": trips,
            "rejected": self.rejected,
            "metrics": {
                "trips": n,
                "trip_lower_bound": lower_bound_trips(self.parcels, self.cap_w, self.cap_v),
                "total_distance": offset,
                "avg_delivery_distance": sum(d for _, d in times) / len(times) if times else 0,
                "avg_express_delivery_distance": sum(exp) / len(exp) if exp else None,
                "weight_utilisation": (sum(t["load_weight"] for t in trips) / (n * self.cap_w)) if n else 0,
                "volume_utilisation": (sum(t["load_volume"] for t in trips) / (n * self.cap_v)) if n else 0,
            },
        }

    def best_plan(self, express_weight=1.0):
        """Run every strategy and keep the cheapest by
        total_distance + express_weight * avg express delivery distance."""
        plans = [self.plan(s) for s in STRATEGIES]
        score = lambda p: p["metrics"]["total_distance"] + express_weight * \
            (p["metrics"]["avg_express_delivery_distance"] or 0)
        return min(plans, key=score), plans
