"""PACKING: how parcels are split into vehicle loads (trips)."""
import math
from .models import PRIORITY_VALUE
from .sorting import merge_sort
from .knapsack import knapsack_2d


def fits(parcels, cap_w, cap_v):
    return sum(p.weight for p in parcels) <= cap_w and sum(p.volume for p in parcels) <= cap_v


def lower_bound_trips(parcels, cap_w, cap_v):
    if not parcels:
        return 0
    return max(math.ceil(sum(p.weight for p in parcels) / cap_w),
               math.ceil(sum(p.volume for p in parcels) / cap_v))


def first_fit_decreasing(parcels, cap_w, cap_v):
    """APPROXIMATION for (vector) bin packing: sort by largest normalised
    dimension, place each parcel in the first load where it fits."""
    size = lambda p: max(p.weight / cap_w, p.volume / cap_v)
    bins = []
    for p in merge_sort(parcels, key=size, reverse=True):
        for b in bins:
            if fits(b + [p], cap_w, cap_v):
                b.append(p)
                break
        else:
            bins.append([p])
    return bins


def plan_trips_priority(parcels, cap_w, cap_v):
    """DP-driven: each trip is the knapsack-optimal selection of the remaining
    parcels, so express parcels ride in the earliest trips."""
    remaining = merge_sort(parcels, key=lambda p: (-PRIORITY_VALUE[p.priority], p.id))
    trips = []
    while remaining:
        if fits(remaining, cap_w, cap_v):
            trips.append(remaining)
            break
        _, chosen = knapsack_2d(remaining, cap_w, cap_v)
        if not chosen:
            raise ValueError("a parcel cannot fit in the vehicle")
        ids = {p.id for p in chosen}
        trips.append(chosen)
        remaining = [p for p in remaining if p.id not in ids]
    return trips


def plan_trips_sweep(parcels, pos, depot, cap_w, cap_v):
    """Geographic 'sweep': sort parcels by polar angle around the depot and cut
    a new trip whenever capacity is reached. Keeps each trip's stops close."""
    dx, dy = pos[depot]
    angle = lambda p: math.atan2(pos[p.dest][1] - dy, pos[p.dest][0] - dx)
    trips, cur = [], []
    for p in merge_sort(parcels, key=lambda p: (angle(p), p.id)):
        if cur and not fits(cur + [p], cap_w, cap_v):
            trips.append(cur)
            cur = []
        cur.append(p)
    if cur:
        trips.append(cur)
    return trips
