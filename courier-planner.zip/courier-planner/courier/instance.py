"""Random problem instance generator and JSON helpers."""
import json
import random


def generate_instance(n_points=12, n_parcels=30, max_weight=40, max_volume=30, seed=7):
    rng = random.Random(seed)
    points = [{"id": f"P{i+1}", "x": round(rng.uniform(0, 100), 1), "y": round(rng.uniform(0, 100), 1)}
              for i in range(n_points)]
    parcels = []
    for i in range(n_parcels):
        parcels.append({
            "id": f"A{i+1:03d}",
            "dest": rng.choice(points)["id"],
            "weight": rng.randint(1, 12),
            "volume": rng.randint(1, 9),
            "priority": rng.choices(["express", "standard", "economy"], [2, 5, 3])[0],
        })
    return {"depot": {"id": "DEPOT", "x": 50, "y": 50}, "points": points,
            "vehicle": {"max_weight": max_weight, "max_volume": max_volume},
            "parcels": parcels}


def load(path):
    with open(path) as f:
        return json.load(f)


def save(obj, path):
    with open(path, "w") as f:
        json.dump(obj, f, indent=2)
