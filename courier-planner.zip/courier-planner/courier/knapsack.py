"""DYNAMIC PROGRAMMING: 0/1 knapsack with two capacity constraints
(weight AND volume), plus a greedy approximation baseline."""
from .sorting import merge_sort


def knapsack_2d(items, cap_w, cap_v):
    """Exact optimum. dp[i][w][v] = best value using the first i items within
    weight w and volume v. Time/space O(n * W * V). Returns (value, chosen)."""
    n = len(items)
    dp = [[[0] * (cap_v + 1) for _ in range(cap_w + 1)] for _ in range(n + 1)]
    for i in range(1, n + 1):
        it = items[i - 1]
        prev, cur = dp[i - 1], dp[i]
        for w in range(cap_w + 1):
            for v in range(cap_v + 1):
                best = prev[w][v]
                if w >= it.weight and v >= it.volume:
                    cand = prev[w - it.weight][v - it.volume] + it.value
                    if cand > best:
                        best = cand
                cur[w][v] = best
    chosen, w, v = [], cap_w, cap_v
    for i in range(n, 0, -1):
        if dp[i][w][v] != dp[i - 1][w][v]:
            it = items[i - 1]
            chosen.append(it)
            w -= it.weight
            v -= it.volume
    chosen.reverse()
    return dp[n][cap_w][cap_v], chosen


def knapsack_greedy(items, cap_w, cap_v):
    """APPROXIMATION baseline: take items by value density (value per unit of
    normalised space) while they fit. O(n log n), fast but not optimal."""
    dens = lambda p: p.value / (p.weight / cap_w + p.volume / cap_v)
    chosen, w, v, total = [], 0, 0, 0
    for p in merge_sort(items, key=dens, reverse=True):
        if w + p.weight <= cap_w and v + p.volume <= cap_v:
            chosen.append(p); w += p.weight; v += p.volume; total += p.value
    return total, chosen
