"""SORTING: stable top-down merge sort, O(n log n), written from scratch."""


def merge_sort(items, key=None, reverse=False):
    key = key or (lambda x: x)

    def _sort(a):
        if len(a) <= 1:
            return list(a)
        mid = len(a) // 2
        left, right = _sort(a[:mid]), _sort(a[mid:])
        out, i, j = [], 0, 0
        while i < len(left) and j < len(right):
            kl, kr = key(left[i]), key(right[j])
            take_left = kl >= kr if reverse else kl <= kr  # ties -> left => stable
            if take_left:
                out.append(left[i]); i += 1
            else:
                out.append(right[j]); j += 1
        out.extend(left[i:])
        out.extend(right[j:])
        return out

    return _sort(list(items))
