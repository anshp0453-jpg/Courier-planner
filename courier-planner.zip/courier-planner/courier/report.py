"""Console report."""


def _fmt(x, nd=1):
    return "-" if x is None else f"{x:.{nd}f}"


def print_comparison(plans, chosen):
    print("\n=== STRATEGY COMPARISON ===")
    print(f"{'strategy':<10}{'trips':>6}{'lower bd':>9}{'total dist':>12}{'avg deliv':>11}{'avg express':>13}{'wt util':>9}")
    for p in plans:
        m = p["metrics"]
        mark = "  <-- selected" if p is chosen else ""
        print(f"{p['strategy']:<10}{m['trips']:>6}{m['trip_lower_bound']:>9}{m['total_distance']:>12.1f}"
              f"{m['avg_delivery_distance']:>11.1f}{_fmt(m['avg_express_delivery_distance']):>13}"
              f"{m['weight_utilisation']*100:>8.0f}%{mark}")


def print_plan(plan, cap_w, cap_v, depot="DEPOT"):
    m = plan["metrics"]
    print(f"\n=== DELIVERY PLAN  (strategy: {plan['strategy']}) ===")
    print(f"{m['trips']} trip(s), total distance {m['total_distance']:.1f}, "
          f"weight utilisation {m['weight_utilisation']*100:.0f}%, "
          f"volume utilisation {m['volume_utilisation']*100:.0f}%")
    for pid, why in plan["rejected"]:
        print(f"  ! parcel {pid} rejected: {why}")
    for t in plan["trips"]:
        print(f"\n--- Trip {t['trip']}: {t['distance']:.1f} units | "
              f"load {t['load_weight']}/{cap_w} kg, {t['load_volume']}/{cap_v} L | {t['route_method']}")
        print("  Route  : " + " -> ".join([depot] + t["stops"] + [depot]))
        ri = t["route_info"]
        if ri["exact_cost"] is not None:
            print(f"  Quality: exact {ri['exact_cost']:.1f} | MST 2-approx {ri['mst_cost']:.1f} "
                  f"(x{ri['ratio_mst']:.3f}) | +2-opt {ri['mst_2opt_cost']:.1f} (x{ri['ratio_2opt']:.3f})")
        else:
            print(f"  Quality: MST 2-approx {ri['mst_cost']:.1f} -> +2-opt {ri['mst_2opt_cost']:.1f}")
        print("  Load order (first in -> last in): " + ", ".join(t["loading_order"]))
    print()
