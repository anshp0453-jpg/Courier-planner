"""ROUTING: exact Held-Karp DP and a 2-approximation (MST) for the
travelling-salesman tour depot -> stops -> depot."""
INF = float("inf")


def tour_cost(tour, d):
    return sum(d[a][b] for a, b in zip(tour, tour[1:]))


def held_karp(depot, stops, d):
    """EXACT dynamic programming over subsets: O(2^n * n^2).
    dp[mask][j] = cheapest path leaving the depot, visiting `mask`, ending at j."""
    n = len(stops)
    if n == 0:
        return 0.0, [depot, depot]
    size = 1 << n
    dp = [[INF] * n for _ in range(size)]
    par = [[-1] * n for _ in range(size)]
    for j in range(n):
        dp[1 << j][j] = d[depot][stops[j]]
    for mask in range(1, size):
        for j in range(n):
            cur = dp[mask][j]
            if cur == INF or not (mask >> j) & 1:
                continue
            for k in range(n):
                if (mask >> k) & 1:
                    continue
                nm = mask | (1 << k)
                c = cur + d[stops[j]][stops[k]]
                if c < dp[nm][k]:
                    dp[nm][k] = c
                    par[nm][k] = j
    full = size - 1
    best, last = min((dp[full][j] + d[stops[j]][depot], j) for j in range(n))
    order, mask, j = [], full, last
    while j != -1:
        order.append(stops[j])
        pj = par[mask][j]
        mask ^= 1 << j
        j = pj
    order.reverse()
    return best, [depot] + order + [depot]


def mst_two_approx(depot, stops, d):
    """APPROXIMATION: build an MST with Prim, walk it in preorder, shortcut
    repeats. For metric distances the tour costs <= 2 * optimal."""
    nodes = [depot] + list(stops)
    in_tree = {depot}
    best = {n: (d[depot][n], depot) for n in stops}
    children = {n: [] for n in nodes}
    while len(in_tree) < len(nodes):
        u = min((n for n in nodes if n not in in_tree), key=lambda n: best[n][0])
        children[best[u][1]].append(u)
        in_tree.add(u)
        for v in nodes:
            if v not in in_tree and d[u][v] < best[v][0]:
                best[v] = (d[u][v], u)
    order, stack = [], [depot]
    while stack:
        u = stack.pop()
        order.append(u)
        stack.extend(reversed(children[u]))
    tour = order + [depot]
    return tour_cost(tour, d), tour


def two_opt(tour, d):
    """LOCAL SEARCH: reverse segments while doing so shortens the tour."""
    t = list(tour)
    improved = True
    while improved:
        improved = False
        for i in range(1, len(t) - 2):
            for j in range(i + 1, len(t) - 1):
                delta = d[t[i - 1]][t[j]] + d[t[i]][t[j + 1]] \
                      - d[t[i - 1]][t[i]] - d[t[j]][t[j + 1]]
                if delta < -1e-9:
                    t[i:j + 1] = reversed(t[i:j + 1])
                    improved = True
    return tour_cost(t, d), t


def solve_route(depot, stops, d, exact_limit=12):
    """Always compute the approximation; add the exact optimum when the trip
    is small enough, and report the observed approximation ratio."""
    mst_cost, mst_tour = mst_two_approx(depot, stops, d)
    opt_cost, opt_tour = two_opt(mst_tour, d)
    info = {"mst_cost": mst_cost, "mst_2opt_cost": opt_cost,
            "exact_cost": None, "ratio_mst": None, "ratio_2opt": None}
    if len(stops) <= exact_limit:
        ex_cost, ex_tour = held_karp(depot, stops, d)
        info.update(exact_cost=ex_cost, method="Held-Karp (exact DP)")
        if ex_cost > 0:
            info["ratio_mst"] = mst_cost / ex_cost
            info["ratio_2opt"] = opt_cost / ex_cost
        cost, tour = ex_cost, ex_tour
    else:
        info["method"] = "MST 2-approx + 2-opt"
        cost, tour = opt_cost, opt_tour
    info.update(cost=cost, order=tour[1:-1])
    return info
