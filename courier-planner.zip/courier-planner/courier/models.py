"""Domain model."""
from dataclasses import dataclass

# Business value of delivering each service level sooner
PRIORITY_VALUE = {"express": 100, "standard": 30, "economy": 10}


@dataclass(frozen=True)
class Parcel:
    id: str
    dest: str
    weight: int      # kg (whole units, rounded up on load)
    volume: int      # litres (whole units, rounded up on load)
    priority: str = "standard"

    @property
    def value(self) -> int:
        """Knapsack value: priority dominates, size is a small tie-break
        that nudges the DP toward fuller vehicles."""
        return PRIORITY_VALUE[self.priority] * 100 + self.weight + self.volume
