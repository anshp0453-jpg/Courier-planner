# Intelligent Courier Planner (prototype)

Given parcels and delivery points, produces **(1) a packing plan** (which parcels go on
which trip and in what loading order) and **(2) an ordered delivery route** for each trip.

    python3 main.py                                   # demo instance, auto-picks best strategy
    python3 main.py --input data/sample_instance.json --strategy priority
    python3 main.py --points 40 --parcels 80 --max-weight 120 --max-volume 90
    python3 -m unittest discover -s tests             # correctness tests

Outputs: console report, `output/plan.json`, `output/route_map.svg`. Pure Python 3 standard library.

## Pipeline and where each technique is used
| Stage | Technique | File |
|---|---|---|
| Road network, shortest distances between all stops | **Graph**: Dijkstra (heap), union-find connectivity | `graph.py` |
| Order parcels by priority / angle / size; loading order | **Sorting**: stable merge sort | `sorting.py` |
| Choose the best subset of parcels per trip (weight + volume limits) | **DP**: 2-D 0/1 knapsack, exact | `knapsack.py` |
| Order stops within a trip | **DP**: Held-Karp exact TSP (<= `--exact-limit` stops) | `tsp.py` |
| Large trips; baselines | **Approximation**: MST 2-approx TSP + 2-opt, FFD bin packing, density-greedy knapsack | `tsp.py`, `packing.py`, `knapsack.py` |
| Compare packing strategies | priority (DP), sweep (angle sort), ffd (bin-packing) | `planner.py` |

## Strategies
- `priority`: repeated knapsack DP, express parcels leave first. Higher distance, fastest express delivery.
- `sweep`: sort by angle around the depot and cut trips at capacity. Compact routes, lowest distance.
- `ffd`: first-fit-decreasing; uses few trips but ignores geography.
- `auto` (default): runs all and picks the lowest `total_distance + express_weight * avg_express_delivery`.

## Input format (`data/sample_instance.json`)
`depot`, `points` (id, x, y), `vehicle` (max_weight kg, max_volume L), `parcels`
(id, dest, weight, volume, priority = express|standard|economy), and optional `roads` as
`[u, v, length]` triples. Without `roads`, a connected road graph is generated.
Parcels that exceed the vehicle capacity or name an unknown point are reported as rejected.

## Assumptions / limits
- One vehicle running trips back-to-back; "delivery time" = distance travelled so far.
- Weights/volumes are rounded up to whole units (DP table is O(n·W·V)).
- Held-Karp is O(2^n·n²), so exact routing is capped (default 12 stops/trip).
- MST 2-approximation bound holds because routing uses shortest-path (metric) distances.
- Greedy knapsack has no proven bound with two constraints; it is only a comparison baseline.
